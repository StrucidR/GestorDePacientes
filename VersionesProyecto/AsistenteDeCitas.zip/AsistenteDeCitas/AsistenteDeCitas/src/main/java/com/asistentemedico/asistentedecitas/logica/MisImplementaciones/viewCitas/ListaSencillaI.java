package com.asistentemedico.asistentedecitas.logica.MisImplementaciones.viewCitas;

import com.asistentemedico.asistentedecitas.logica.MisImplementaciones.viewCitas.ListaSencilla.Proceso;

public interface ListaSencillaI <T>{
    public void agregar(T elemento);
    public void buscar(Proceso<T> proceso);
    public void limpiar();
}
