package com.asistentemedico.asistentedecitas.logica;

public class Usuario {
    
}
