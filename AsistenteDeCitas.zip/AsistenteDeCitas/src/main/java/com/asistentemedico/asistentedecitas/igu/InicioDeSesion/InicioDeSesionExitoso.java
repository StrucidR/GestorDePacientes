package com.asistentemedico.asistentedecitas.igu.InicioDeSesion;

import com.asistentemedico.asistentedecitas.igu.InicioDeSesion.Agendamientodecita.AgendamientoDeCitas;
import com.asistentemedico.asistentedecitas.igu.InicioDeSesion.Saladeespera.FiltroDeEsperaDeAsistenteMedicos;
import com.asistentemedico.asistentedecitas.igu.InicioDeSesion.Saladeespera.FiltroDeEsperaDeAsistenteMedicosErrorAcceso;
import com.asistentemedico.asistentedecitas.igu.InicioDeSesion.Saladeespera.SalaDeEspera;
import com.asistentemedico.asistentedecitas.igu.Registro.Registro;
import com.asistentemedico.asistentedecitas.igu.Principal.Principal;
import com.asistentemedico.asistentedecitas.igu.autorizacion.RegistrodeordenesAutorizacionEntrada;
import com.asistentemedico.asistentedecitas.igu.examenes.EntradadeExamenes;
import com.asistentemedico.asistentedecitas.igu.pagodecitas.pagodeCitasPrimeraEntrada;


public class InicioDeSesionExitoso extends javax.swing.JFrame {
    public InicioDeSesionExitoso() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lobbyboton = new javax.swing.JButton();
        IniciarSesionboton = new javax.swing.JButton();
        Autorizacionboton = new javax.swing.JButton();
        PagoDeCitasboton = new javax.swing.JButton();
        PagoDeCitasboton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        sobreNosotros2 = new javax.swing.JLabel();
        sobreNosotros3 = new javax.swing.JLabel();
        Especialidad5 = new javax.swing.JRadioButton();
        Especialidad1 = new javax.swing.JRadioButton();
        Especialidad2 = new javax.swing.JRadioButton();
        Especialidad3 = new javax.swing.JRadioButton();
        Especialidad4 = new javax.swing.JRadioButton();
        sobreNosotros = new javax.swing.JLabel();
        Motivo1 = new javax.swing.JRadioButton();
        Motivo2 = new javax.swing.JRadioButton();
        Motivo3 = new javax.swing.JRadioButton();
        AgendarBoton = new javax.swing.JButton();
        SalaDeEspera = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(229, 229, 229));

        jLabel3.setFont(new java.awt.Font("Segoe UI Variable", 1, 30)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 204, 204));
        jLabel3.setText("Asistente de Citas Médicas");

        lobbyboton.setForeground(new java.awt.Color(102, 102, 102));
        lobbyboton.setText("Registrarse");
        lobbyboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lobbybotonActionPerformed(evt);
            }
        });

        IniciarSesionboton.setForeground(new java.awt.Color(102, 102, 102));
        IniciarSesionboton.setText("Lobby");
        IniciarSesionboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IniciarSesionbotonActionPerformed(evt);
            }
        });

        Autorizacionboton.setForeground(new java.awt.Color(102, 102, 102));
        Autorizacionboton.setText("Autorización");
        Autorizacionboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AutorizacionbotonActionPerformed(evt);
            }
        });

        PagoDeCitasboton.setForeground(new java.awt.Color(102, 102, 102));
        PagoDeCitasboton.setText("Pago de Citas");
        PagoDeCitasboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PagoDeCitasbotonActionPerformed(evt);
            }
        });

        PagoDeCitasboton1.setForeground(new java.awt.Color(102, 102, 102));
        PagoDeCitasboton1.setText("Exámenes");
        PagoDeCitasboton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PagoDeCitasboton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(PagoDeCitasboton1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PagoDeCitasboton, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Autorizacionboton, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(IniciarSesionboton, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lobbyboton, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel3))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lobbyboton)
                            .addComponent(IniciarSesionboton)
                            .addComponent(Autorizacionboton)
                            .addComponent(PagoDeCitasboton)
                            .addComponent(PagoDeCitasboton1))))
                .addGap(0, 16, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(229, 229, 229));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("Email: asistentedecitasmedicas@gmail.com");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 8)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("Derechos de autor © 2024 AsistenteDeCitasSA. Todos los derechos reservados. Prohibida la reproducción total o parcial de este sitio web, incluidos textos, imágenes y diseño, sin la autorización previa por escrito de AsistenteDeCitasMedicasSA.");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addGap(17, 17, 17))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel4.setBackground(new java.awt.Color(229, 229, 229));

        sobreNosotros2.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        sobreNosotros2.setForeground(new java.awt.Color(0, 102, 102));
        sobreNosotros2.setText("Especialidad Requerida");

        sobreNosotros3.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        sobreNosotros3.setForeground(new java.awt.Color(0, 102, 102));
        sobreNosotros3.setText("Motivo de Cita");

        Especialidad5.setBackground(new java.awt.Color(229, 229, 229));
        Especialidad5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Especialidad5.setForeground(new java.awt.Color(102, 102, 102));
        Especialidad5.setText("Dermátologia");
        Especialidad5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Especialidad5ActionPerformed(evt);
            }
        });

        Especialidad1.setBackground(new java.awt.Color(229, 229, 229));
        Especialidad1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Especialidad1.setForeground(new java.awt.Color(102, 102, 102));
        Especialidad1.setText("Médicina General");
        Especialidad1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Especialidad1ActionPerformed(evt);
            }
        });

        Especialidad2.setBackground(new java.awt.Color(229, 229, 229));
        Especialidad2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Especialidad2.setForeground(new java.awt.Color(102, 102, 102));
        Especialidad2.setText("Pedíatria");
        Especialidad2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Especialidad2ActionPerformed(evt);
            }
        });

        Especialidad3.setBackground(new java.awt.Color(229, 229, 229));
        Especialidad3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Especialidad3.setForeground(new java.awt.Color(102, 102, 102));
        Especialidad3.setText("Ginecología");
        Especialidad3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Especialidad3ActionPerformed(evt);
            }
        });

        Especialidad4.setBackground(new java.awt.Color(229, 229, 229));
        Especialidad4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Especialidad4.setForeground(new java.awt.Color(102, 102, 102));
        Especialidad4.setText("Cardiología");
        Especialidad4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Especialidad4ActionPerformed(evt);
            }
        });

        sobreNosotros.setFont(new java.awt.Font("Segoe UI Variable", 1, 30)); // NOI18N
        sobreNosotros.setForeground(new java.awt.Color(0, 102, 102));
        sobreNosotros.setText("Bienvenido");

        Motivo1.setBackground(new java.awt.Color(229, 229, 229));
        Motivo1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Motivo1.setForeground(new java.awt.Color(102, 102, 102));
        Motivo1.setText("Valoración");
        Motivo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Motivo1ActionPerformed(evt);
            }
        });

        Motivo2.setBackground(new java.awt.Color(229, 229, 229));
        Motivo2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Motivo2.setForeground(new java.awt.Color(102, 102, 102));
        Motivo2.setText("Exámen");
        Motivo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Motivo2ActionPerformed(evt);
            }
        });

        Motivo3.setBackground(new java.awt.Color(229, 229, 229));
        Motivo3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Motivo3.setForeground(new java.awt.Color(102, 102, 102));
        Motivo3.setText("Control");
        Motivo3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Motivo3ActionPerformed(evt);
            }
        });

        AgendarBoton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AgendarBoton.setForeground(new java.awt.Color(0, 102, 102));
        AgendarBoton.setText("Agendar");
        AgendarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgendarBotonActionPerformed(evt);
            }
        });

        SalaDeEspera.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SalaDeEspera.setForeground(new java.awt.Color(0, 102, 102));
        SalaDeEspera.setText("Sala de espera");
        SalaDeEspera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalaDeEsperaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sobreNosotros2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sobreNosotros3, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AgendarBoton)
                    .addComponent(Motivo3, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Motivo2, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Motivo1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sobreNosotros, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Especialidad1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Especialidad2, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Especialidad3, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Especialidad4, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Especialidad5, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SalaDeEspera))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sobreNosotros)
                .addGap(18, 18, 18)
                .addComponent(sobreNosotros2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Especialidad1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Especialidad2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Especialidad3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Especialidad4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Especialidad5)
                .addGap(18, 18, 18)
                .addComponent(sobreNosotros3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Motivo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Motivo2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Motivo3)
                .addGap(26, 26, 26)
                .addComponent(AgendarBoton)
                .addGap(18, 18, 18)
                .addComponent(SalaDeEspera)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lobbybotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lobbybotonActionPerformed
        this.dispose();
        Registro regis= new Registro();
        regis.setVisible(true);
        regis.setLocationRelativeTo(null);
        regis.setResizable(false);
    }//GEN-LAST:event_lobbybotonActionPerformed

    private void IniciarSesionbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IniciarSesionbotonActionPerformed
        this.dispose();
        Principal princ=new Principal();
        princ.setVisible(true);
        princ.setLocationRelativeTo(null);
        princ.setResizable(false);
    }//GEN-LAST:event_IniciarSesionbotonActionPerformed

    private void AutorizacionbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AutorizacionbotonActionPerformed
                               this.dispose();
        RegistrodeordenesAutorizacionEntrada prim = new RegistrodeordenesAutorizacionEntrada();
                prim.setVisible(true);
        prim.setLocationRelativeTo(null);
        prim.setResizable(false);
    }//GEN-LAST:event_AutorizacionbotonActionPerformed

    private void PagoDeCitasbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PagoDeCitasbotonActionPerformed
                this.dispose();
        pagodeCitasPrimeraEntrada prim = new pagodeCitasPrimeraEntrada();
                prim.setVisible(true);
        prim.setLocationRelativeTo(null);
        prim.setResizable(false);
    }//GEN-LAST:event_PagoDeCitasbotonActionPerformed

    private void PagoDeCitasboton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PagoDeCitasboton1ActionPerformed

               this.dispose();
               EntradadeExamenes prim = new EntradadeExamenes();
                prim.setVisible(true);
        prim.setLocationRelativeTo(null);
        prim.setResizable(false);
    }//GEN-LAST:event_PagoDeCitasboton1ActionPerformed

    private void Especialidad2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Especialidad2ActionPerformed
    
    Especialidad3.setSelected(false);
    Especialidad4.setSelected(false);
    Especialidad5.setSelected(false);
    Especialidad1.setSelected(false);
    }//GEN-LAST:event_Especialidad2ActionPerformed

    private void Especialidad3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Especialidad3ActionPerformed
    Especialidad1.setSelected(false);
    Especialidad2.setSelected(false);
    Especialidad4.setSelected(false);
    Especialidad5.setSelected(false);
    }//GEN-LAST:event_Especialidad3ActionPerformed

    private void Especialidad4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Especialidad4ActionPerformed
    Especialidad1.setSelected(false);
    Especialidad2.setSelected(false);
    Especialidad3.setSelected(false);
    Especialidad5.setSelected(false);
    }//GEN-LAST:event_Especialidad4ActionPerformed

    private void Especialidad5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Especialidad5ActionPerformed
    Especialidad1.setSelected(false);
    Especialidad2.setSelected(false);
    Especialidad3.setSelected(false);
    Especialidad4.setSelected(false);
    }//GEN-LAST:event_Especialidad5ActionPerformed

    private void Motivo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Motivo1ActionPerformed
    Motivo2.setSelected(false);
    Motivo3.setSelected(false);
    }//GEN-LAST:event_Motivo1ActionPerformed

    private void Motivo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Motivo2ActionPerformed
    Motivo1.setSelected(false);
    Motivo3.setSelected(false);
    }//GEN-LAST:event_Motivo2ActionPerformed

    private void Motivo3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Motivo3ActionPerformed
    Motivo1.setSelected(false);
    Motivo2.setSelected(false);
    }//GEN-LAST:event_Motivo3ActionPerformed

    private void AgendarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgendarBotonActionPerformed
          boolean especialidadSeleccionada = Especialidad1.isSelected() || Especialidad2.isSelected() || Especialidad3.isSelected() || Especialidad4.isSelected() || Especialidad5.isSelected();
    boolean motivoSeleccionado = Motivo1.isSelected() || Motivo2.isSelected() || Motivo3.isSelected();
        
            if (especialidadSeleccionada && motivoSeleccionado) {
        // Si se cumple, proceder al AgendamientoDeCitas
        AgendamientoDeCitas agend = new AgendamientoDeCitas();
        this.dispose();
        agend.setVisible(true);
        agend.setLocationRelativeTo(null);
        agend.setResizable(false);
    } else {
        
        ErrorAlAgendarOPasarALaSalaDeEspera agend = new ErrorAlAgendarOPasarALaSalaDeEspera();
        this.dispose();
        agend.setVisible(true);
        agend.setLocationRelativeTo(null);
        agend.setResizable(false);
    }
    }//GEN-LAST:event_AgendarBotonActionPerformed

    private void SalaDeEsperaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalaDeEsperaActionPerformed
          boolean especialidadSeleccionada = Especialidad1.isSelected() || Especialidad2.isSelected() || Especialidad3.isSelected() || Especialidad4.isSelected() || Especialidad5.isSelected();
    boolean motivoSeleccionado = Motivo1.isSelected() || Motivo2.isSelected() || Motivo3.isSelected();
        
            if (especialidadSeleccionada && motivoSeleccionado) {
        // Si se cumple, proceder al AgendamientoDeCitas
                FiltroDeEsperaDeAsistenteMedicos agend = new FiltroDeEsperaDeAsistenteMedicos();
        this.dispose();
        agend.setVisible(true);
        agend.setLocationRelativeTo(null);
        agend.setResizable(false);
    } else {
        this.dispose();
        ErrorAlAgendarOPasarALaSalaDeEspera agend = new ErrorAlAgendarOPasarALaSalaDeEspera();
        
        agend.setVisible(true);
        agend.setLocationRelativeTo(null);
        agend.setResizable(false);
    }
        
    }//GEN-LAST:event_SalaDeEsperaActionPerformed

    private void Especialidad1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Especialidad1ActionPerformed
    Especialidad2.setSelected(false);
    Especialidad3.setSelected(false);
    Especialidad4.setSelected(false);
    Especialidad5.setSelected(false);
    }//GEN-LAST:event_Especialidad1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AgendarBoton;
    private javax.swing.JButton Autorizacionboton;
    private javax.swing.JRadioButton Especialidad1;
    private javax.swing.JRadioButton Especialidad2;
    private javax.swing.JRadioButton Especialidad3;
    private javax.swing.JRadioButton Especialidad4;
    private javax.swing.JRadioButton Especialidad5;
    private javax.swing.JButton IniciarSesionboton;
    private javax.swing.JRadioButton Motivo1;
    private javax.swing.JRadioButton Motivo2;
    private javax.swing.JRadioButton Motivo3;
    private javax.swing.JButton PagoDeCitasboton;
    private javax.swing.JButton PagoDeCitasboton1;
    private javax.swing.JButton SalaDeEspera;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton lobbyboton;
    private javax.swing.JLabel sobreNosotros;
    private javax.swing.JLabel sobreNosotros2;
    private javax.swing.JLabel sobreNosotros3;
    // End of variables declaration//GEN-END:variables
}
