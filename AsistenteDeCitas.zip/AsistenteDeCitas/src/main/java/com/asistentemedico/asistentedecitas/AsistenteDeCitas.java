package com.asistentemedico.asistentedecitas;

import com.asistentemedico.asistentedecitas.igu.Principal.Principal;


public class AsistenteDeCitas {

    public static void main(String[] args) {
        Principal princ= new Principal();
        princ.setResizable(false);
        princ.setVisible(true);
        princ.setLocationRelativeTo(null);
    }
}
