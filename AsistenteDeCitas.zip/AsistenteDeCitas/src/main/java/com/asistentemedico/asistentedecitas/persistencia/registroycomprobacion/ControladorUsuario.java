package com.asistentemedico.asistentedecitas.persistencia.registroycomprobacion;

import com.asistentemedico.asistentedecitas.logica.Usuario;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ControladorUsuario {

    private static final String RUTA_ARCHIVO = "src/main/java/com/asistentemedico/asistentedecitas/persistencia/usuarios.txt";

    public static boolean validarInicioSesion(String nombre, String apellido, String identificacion, String contrasenia) {
        List<Usuario> usuarios = cargarUsuarios();
        for (Usuario usuario : usuarios) {
            if (usuario.getNombre().equalsIgnoreCase(nombre)
                && usuario.getApellido().equalsIgnoreCase(apellido)
                && usuario.getIdentificacion().equals(identificacion)
                && usuario.getContrasenia().equals(contrasenia)) {
                return true; // Usuario encontrado, inicio de sesión exitoso
            }
        }
        return false; // Usuario no encontrado, inicio de sesión fallido
    }

    private static List<Usuario> cargarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(RUTA_ARCHIVO))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                Usuario usuario = parsearUsuario(linea);
                usuarios.add(usuario);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    private static Usuario parsearUsuario(String linea) {
        String[] partes = linea.split(",");
        if (partes.length >= 6) {
            String nombre = partes[0].trim();
            String apellido = partes[1].trim();
            String identificacion = partes[2].trim();
            String edad = partes[3].trim();
            String telefono = partes[4].trim();
            String contrasenia = partes[5].trim();
            return new Usuario(nombre, apellido, identificacion, edad, telefono, contrasenia);
        } else {
            return null;
        }
    }
}
